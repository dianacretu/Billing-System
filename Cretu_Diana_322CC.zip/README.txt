	***************************************
        *               README                  *
        *                                       *
        *       Nume proiect: Tema POO      	*
        *       Autor: Diana Cretu              *
        *       Grupa: 322 CC                   *
        *       Deadline: Sambata, 13.01.2018   *
        *       Timp de lucru: 5 zile           *
        *       Grad de dificultate: mediu      *
        *					*
        ***************************************

1. Ierarhia proiectului

	Codul sursa este structurat in package'ul Apl.


2. Descrierea aplicatiei

	Programul scris in Java si este format din 2 
parti: prima parte se poate rula din clasa Verificare,
iar cea de-a doua parte din clasa Interfata, realizata 
cu ajutorul editorului de design pus la dispozitie de
NetBeans 8.2.


3. Implementare
	
	Prima parte a fost realizata conform cerintei 
cu clasele specificate, iar scrierea in fisier se realizeaza
in main.
	A doua parte, interfata, se deschide cu o fereastra de
login, unde va puteti autentifica cu contul:
	username: dianacretu
	parola: temapoo
	Dupa ce userul a fost acceptat se va deschide pagina de 
home. Apasand primul buton, se deschide pagina de unde puteti incarca
cele 3 fisiere: "produse.txt", "facturi.txt" si "taxe.txt". Apasand
butonul Gestiune se va crea obiectul din clasa cu acelasi nume.
	Pentru a ne intoarce la pagina de home putem apasa butonul 
"Back". 
	Cel de-al doilea buton, ne va duce la pagina de produse.
Putem observa toate produsele selectand modul de a le vedea in tabel:
dupa denumire sau tara in ordine alfabetica. Pentru a adauga un produs
nou se apasa butonul de "Add" si specificam numele, categoria, pretul
si una din tarile deja existente.
	Pentru a sterge un produs, apasam randul respectiv din tabel
si apoi butonul "Delete".
	In continuare, avem butonul de "Back" pentru a ne putea intoarce
la pagina de home.
	Ultimul buton, cel de Gestiune va deschide un nou panel de unde putem
selecta ce dorim sa apara in zona de text intre: magazinul cu cele mai mari
vanzari, magazinul cu cele mai mari vanzari pentru fiecare tara, pentru 
fiecare categorie si factura cu suma cea mai mare.

	***************************************
        *               END README              *
        *                                       *
        *       Nume proiect: Tema POO          *
        *       Autor: Diana Cretu      	*
        *       Grupa: 322 CC                   *
        *       Deadline: Joi, 13.01.2018	*
        *                                       *
        *                                       *
        ***************************************