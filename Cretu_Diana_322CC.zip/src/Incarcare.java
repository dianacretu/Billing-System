
import java.io.File;
import java.util.ArrayList;
import javax.swing.*;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author diana
 */
public class Incarcare extends JFileChooser {
    public Incarcare (String text) {
        super(text);
        showOpenDialog(null);
        ArrayList<File> f1 = new ArrayList();
    //    File[] f1 = JFileChooser.getSelectedFiles();
      //  File f2 = getSelectedFile();
       // File f3 = getSelectedFile();
        System.out.println(f1.toString());
    }
}
