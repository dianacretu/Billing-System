/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author diana
 */
public class ProdusComandat {
    
    private Produs produs;
    private double taxe;
    private int cantitate;
    
    ProdusComandat(Produs produs, double taxe, int cantitate) {
        this.produs = produs;
        this.taxe = taxe;
        this.cantitate = cantitate;
    }
    
    void setProdus(Produs produs) {
        this.produs = produs;
    }
    
    Produs getProdus() {
        return produs;
    }
    
    void setTaxe(double taxe) {
        this.taxe = taxe;
    }
    
    double getTaxe(){
        return taxe;
    }
    
    void setCantitate(int cantitate) {
        this.cantitate = cantitate;
    }
    
    int getCantitate() {
        return cantitate;
    }
    
    public String toString() {
        return produs + " " + taxe + " " + cantitate;
    }
    
}
