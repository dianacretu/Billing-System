
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;
import java.util.TreeMap;
import java.util.Vector;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author diana
 */
public class Gestiune {
    ArrayList<Produs> produse;
    int nrProduse;
    ArrayList<Magazin> magazine;
    TreeMap<String,TreeMap<String,Integer>> dictionar;
    
    private static Gestiune instance = null;
    
    private Gestiune() {
        produse = new ArrayList();
        nrProduse = 0;
        magazine = new ArrayList();
        dictionar = new TreeMap<String,TreeMap<String,Integer>>();
    }
    
    public static Gestiune getInstance() {
        if (instance == null) {
            instance = new Gestiune();
        }
        return instance;
    }
  
    void creazaProdus(String file) throws FileNotFoundException {
        Scanner s = new Scanner(new File(file));
     //   ArrayList<Produs> produse = new ArrayList();
        ArrayList<String> tara = new ArrayList();
        String cuv = null;
        String cuv2 = null;
        String denumire, taraOrigine, categorie;
        double pret;
        int i = 0,j = 0;
        cuv = s.nextLine();
        Scanner sc = new Scanner(cuv);
        while ( i < 2 ) {
            cuv2 = sc.next();
            i ++;
        }
        while (sc.hasNext()) {
            cuv2 = sc.next();
            tara.add(cuv2);
            j++;
        }
        while (s.hasNext()) {
            cuv = s.nextLine();
            Scanner sc2 = new Scanner(cuv);
            denumire = sc2.next();
            categorie = sc2.next();
            int index = 0;
            while (sc2.hasNext()) {
                taraOrigine = tara.get(index);
                pret = Double.parseDouble(sc2.next());
                Produs p = new Produs(denumire, categorie, taraOrigine, pret);
                produse.add(p);
                nrProduse ++;
                index ++;
            }
            sc2.close();    
        }
        System.out.println(produse);
        sc.close();
    }
    
    ProdusComandat creeazaProdusComandat(String line, String fileTaxe) throws FileNotFoundException {
        String denumire, tara;
        Scanner sc = new Scanner(line);
        denumire = sc.next();
        tara = sc.next();
        Produs produs = new Produs();
        for (int j = 0; j < nrProduse; j++) {
            if ((produse.get(j).getDenumire().equals(denumire)) 
                && (produse.get(j).getTaraOrigine().equals(tara))) {
                    produs = produse.get(j);
            }
        }
        int cantitate = sc.nextInt();
        Scanner sc3 = new Scanner(new File(fileTaxe));
        String lineTaxe = sc3.nextLine();
    //    System.out.println(lineTaxe);
        Scanner sc4 = new Scanner(lineTaxe);
        String taraTaxe = sc4.next();
        taraTaxe = sc4.next();
        int indiceTara = 0;
        while (!taraTaxe.equals(tara)) {
            taraTaxe = sc4.next();
            indiceTara ++;
        }
        while (!taraTaxe.equals(produs.getCategorie())) {
            lineTaxe = sc3.nextLine();
            sc4 = new Scanner(lineTaxe);
            taraTaxe = sc4.next();
        }
        for (int j = 0; j < indiceTara + 1; j ++) {
            taraTaxe = sc4.next();
        }
        double taxe = Double.parseDouble(taraTaxe);
        ProdusComandat produsComandat = new ProdusComandat(produs, taxe, cantitate);
        return produsComandat;
    }
    
    void creeazaFactura(String fileFacturi, String fileTaxe) throws FileNotFoundException {
        Scanner s = new Scanner(new File(fileFacturi));
        String cuv = null;
        String cuv2 = null;
        while (s.hasNext()) {
            cuv = s.nextLine();
         //   System.out.println(cuv);
            Scanner sc = new Scanner(cuv);
            if (!cuv.isEmpty()) {
                cuv2 = sc.next();
            }
       //     System.out.println(cuv2);
            while (!cuv2.contains("Factura")) {
                cuv = s.nextLine();
            //    System.out.println(cuv);
                sc = new Scanner(cuv);
                if (!cuv.isEmpty()) {
                    cuv2 = sc.next();
                }
            }
        //    System.out.println(cuv2);
            String denumire = cuv2;
          //  System.out.println(denumire);
            
            cuv = s.nextLine();
            cuv2 = "a";
            Vector<ProdusComandat> produseCom = new Vector();
            while ((!cuv.isEmpty()) && s.hasNext()) {
                cuv = s.nextLine();
                if (!cuv.isEmpty()) {
                    produseCom.add(creeazaProdusComandat(cuv, fileTaxe));
                }
            }
            Factura factura = new Factura(denumire, produseCom);
         //   System.out.println(produseCom);
          
        }    
    }
    
    void creeazaTaxe(String fileTaxe) throws FileNotFoundException {
        Scanner s = new Scanner(new File(fileTaxe));
        String cuv, cuv2 = "";
        cuv = s.nextLine();
        //System.out.println(cuv);
        Scanner sc = new Scanner(cuv);
        String tara = sc.next();
    //    cuv2 = s.nextLine();
        System.out.println(cuv2);
        int coloana = 1;
        while (sc.hasNext()) {
            tara = sc.next();
            coloana ++;
            TreeMap<String, Integer> categPro = new TreeMap();
            Scanner sca = new Scanner(new File(fileTaxe));
            cuv2 = sca.nextLine();
            while (sca.hasNext()) {
                cuv2 = sca.nextLine();
                Scanner sc2 = new Scanner(cuv2);
                String categorie = sc2.next();
                int procent = 0;
                int i = 1;
                while (i < coloana) {
                    procent = sc2.nextInt();
                    i ++;
                }
                categPro.put(categorie, procent);
            }
            dictionar.put(tara, categPro);
        }
        System.out.println(dictionar);
        
           /* Scanner sc2 = new Scanner(cuv2);
            String categorie = sc2.next();
            int procent = 0;
           // System.out.println(categorie);
            while (sc.hasNext()) {
                tara = sc.next();
                procent = sc2.nextInt();
                TreeMap<String, Integer> categPro = new TreeMap();
                categPro.put(categorie, procent);
                dictionar.put(tara, categPro);
               // System.out.println(dictionar);
            }*/
    //    System.out.println(dictionar);
        
       // System.out.println(dictionar);
    }
    
    void creeazaMagazin(String fileFactura, String fileTaxe) throws FileNotFoundException {
        Scanner sca = new Scanner(new File(fileFactura));
        StringBuilder linie = new StringBuilder(sca.nextLine());
        String nume, tip = "";
    //    linie.delete(0, linie.length());
    //    linie.append(sca.nextLine());
        while (sca.hasNext()) {
            
              while (!linie.toString().contains("Magazin") && sca.hasNext()) {
                 // linie = sca.nextLine();
                linie.delete(0, linie.length());
                 linie.append(sca.nextLine());
              }
     /*       if (!s.hasNext()) {
                break;
            }*/
         //   System.out.println(linie);
          //  String lin = linie;
            Scanner sc = new Scanner(linie.toString()).useDelimiter(":");
            for (int i = 0; i < 2; i ++) {
                tip = sc.next();
            }
            nume = sc.next();
        //    System.out.println(tip);
            Scanner s = sca;
            
            Vector<Factura> fact = new Vector();
            fact = creeazaFact(s, linie, fileTaxe);
        //    System.out.println(MagazinFactory.getMagazin(nume, tip, fact));
            magazine.add(MagazinFactory.getMagazin(nume, tip, fact));
        }
        System.out.println(magazine);
    }
    
    String getLinie(String linie) {
        return linie;
    }
    
    Vector<Factura> creeazaFact(Scanner s, StringBuilder linie, String fileTaxe) throws FileNotFoundException {
    //    System.out.println(s.nextLine());
    //    String cuv = "";
        String cuv2 = "";
        Vector<Factura> facturi = new Vector();
        while (s.hasNext()) {
            if (s.hasNext()) {
                //linie = s.nextLine();
                linie.delete(0, linie.length());
                linie.append(s.nextLine());
            }
            if (linie.toString().contains("Magazin")) {
                break;
            }
            Scanner sc = new Scanner(linie.toString());
            if (!linie.toString().isEmpty()) {
                cuv2 = sc.next();
            }
       //     System.out.println(cuv2);
            while (!cuv2.contains("Factura")) {
             //   linie = s.nextLine();
                linie.delete(0, linie.length());
                 linie.append(s.nextLine());
            //    System.out.println(cuv);
                sc = new Scanner(linie.toString());
                if (!linie.toString().isEmpty()) {
                    cuv2 = sc.next();
                }
            }
        //    System.out.println(cuv2);
            String denumire = cuv2;
          //  System.out.println(denumire);
            
        //    linie = s.nextLine();
            linie.delete(0, linie.length());
            linie.append(s.nextLine());
            cuv2 = "a";
            Vector<ProdusComandat> produseCom = new Vector();
            while ((!linie.toString().isEmpty()) && s.hasNext()) {
              //  linie = s.nextLine();
                linie.delete(0, linie.length());
                linie.append(s.nextLine());
                if (!linie.toString().isEmpty()) {
                    produseCom.add(creeazaProdusComandat(linie.toString(), fileTaxe));
                }
            }
            Factura factura = new Factura(denumire, produseCom);
            facturi.add(factura);
        }
     //   linie = s.nextLine();
      //  System.out.println(linie);
        return facturi;
    }
}
