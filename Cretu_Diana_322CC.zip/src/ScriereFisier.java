
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author diana
 */
public class ScriereFisier {
    void scrie() throws IOException {
        File fisier = new File("a.txt");
        if (!fisier.exists()) {
            fisier.createNewFile();
        }
        FileWriter fw = new FileWriter(fisier);
        BufferedWriter bw = new BufferedWriter(fw);
        bw.write("MiniMarket");
        bw.close();
    }
}
