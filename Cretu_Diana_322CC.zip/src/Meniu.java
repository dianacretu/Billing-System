import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;

/**
 *
 * @author diana
 */public class Meniu extends JFrame implements ActionListener{
   // private JButton button;
    
    public Meniu(String text) {
        super(text);
    //    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setMinimumSize(new Dimension(300,200));
        getContentPane().setBackground(Color.black);
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
    gbc.gridwidth = GridBagConstraints.REMAINDER;
gbc.fill = GridBagConstraints.HORIZONTAL;
        JButton button = new JButton("Incarcare produse.txt");
        JButton button2 = new JButton("Incarcare taxe.txt");
        JButton button3 = new JButton("Incarcare facturi.txt");
        button.addActionListener(this);
        button.setBackground(Color.pink);
     //   button.setSize(2,1);
        button2.addActionListener(this);
        button2.setBackground(Color.pink);
        button3.addActionListener(this);
        button3.setBackground(Color.pink);
    //    button2.setSize(1,1);
        add(button, gbc);
        add(button2, gbc);
        add(button3, gbc);
        show();
        pack();  
    }
    
    /*public static void main(String args[]) {
        Menu b = new Menu("Menu");
    }*/

    @Override
    public void actionPerformed(ActionEvent e) {
        JButton button = (JButton) e.getSource();
        File produse, taxe, facturi;
        if (button.getText().equals("Incarcare produse.txt")) {
           JFileChooser fc = new JFileChooser();
           int option = fc.showOpenDialog(null);
           if(option == JFileChooser.APPROVE_OPTION) {
                produse = fc.getSelectedFile();
           }
           else if (option == JFileChooser.CANCEL_OPTION){
                System.out.println(" User cancelled operation. No file was chosen.");  
           }
           button.setBackground(Color.blue);
        } 
     
        if (button.getText().equals("Incarcare taxe.txt")) {
           JFileChooser fc = new JFileChooser();
           int option = fc.showOpenDialog(null);
           if(option == JFileChooser.APPROVE_OPTION) {
                taxe = fc.getSelectedFile();
           }
           else if (option == JFileChooser.CANCEL_OPTION){
                System.out.println(" User cancelled operation. No file was chosen.");  
           }
           button.setBackground(Color.blue);
        }
        if (button.getText().equals("Incarcare facturi.txt")) {
           JFileChooser fc = new JFileChooser();
           int option = fc.showOpenDialog(null);
           if(option == JFileChooser.APPROVE_OPTION) {
                facturi = fc.getSelectedFile();
           }
           else if (option == JFileChooser.CANCEL_OPTION){
                System.out.println(" User cancelled operation. No file was chosen.");  
           }
           button.setBackground(Color.blue);
        }
        if (button.getText().equals("Gestiune")) {
        //    Gestiune g = Gestiune.getInstance();
           button.setBackground(Color.blue);
        }
    }
    
}
