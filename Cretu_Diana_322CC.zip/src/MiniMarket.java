
import java.util.Vector;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author diana
 */
public class MiniMarket extends Magazin{
   // String tip;
    
    MiniMarket(String nume, String tip, Vector facturi) {
        super(nume, tip, facturi);
     //   this.tip = tip;
    }
    
    @Override
    public double calculScutiriTaxe() {
        Vector<String> tari = new Vector();
        String tara = " ";
        for (int i = 0; i < facturi.size(); i ++) {
            for (int j = 0; j < facturi.get(i).produseCom.size(); j ++) {
                if (!tari.contains(facturi.get(i).produseCom.get(j).getProdus().getTaraOrigine())) {
                    tara = facturi.get(i).produseCom.get(j).getProdus().getTaraOrigine();
                    tari.add(tara);
                }
            }
        }
        for (int i = 0; i < tari.size(); i ++) {
            if (getTotalTaraCuTaxe(tari.get(i)) > (getTotalCuTaxe()/2)) {
                return 0.1;
            }
        }
        return 0;
    }
    
}
