
import java.util.Vector;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author diana
 */
public abstract class Magazin implements IMagazin{
    String nume, tip;
    Vector<Factura> facturi;
    
    Magazin() {
        nume = "";
        tip = "";
        facturi = new Vector();
    }
    
    Magazin(String nume, String tip, Vector<Factura> facturi) {
        this.nume = nume;
        this.tip = tip;
        this.facturi = facturi;
    }

    @Override
    public double getTotalFaraTaxe() {
        double suma = 0;
        for (int i = 0; i < facturi.size(); i ++) {
            suma  = suma + facturi.get(i).getTotalFaraTaxe();
        }
        return suma;
    }

    @Override
    public double getTotalCuTaxe() {
        double suma = 0;
        for (int i = 0; i < facturi.size(); i ++) {
            suma  = suma + facturi.get(i).getTotalCuTaxe();
        }
        return suma;
    }

    @Override
    public double getTotalCuTaxeScutite() {
        return getTotalCuTaxe() - getTotalCuTaxe()*calculScutiriTaxe();
    }

    @Override
    public double getTotalTaraFaraTaxe(String tara) {
        double suma = 0;
        for (int i = 0; i < facturi.size(); i ++) {
            suma = suma + facturi.get(i).getTotalTaraFaraTaxe(tara);
        }
        return suma;
    }

    @Override
    public double getTotalTaraCuTaxe(String tara) {
        double suma = 0;
        for (int i = 0; i < facturi.size(); i ++) {
            suma = suma + facturi.get(i).getTotalTaraCuTaxe(tara);
        }
        return suma;
    }

    @Override
    public double getTotalTaraCuTaxeScutite(String tara) {
        return getTotalTaraCuTaxe(tara) - getTotalTaraCuTaxe(tara)*calculScutiriTaxe();
    }

    @Override
    public abstract double calculScutiriTaxe();
    
    @Override
    public String toString() {
        return nume + " " + facturi;
    }
}
