/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Apl;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;
import static java.time.format.SignStyle.ALWAYS;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SpringLayout;

/**
 *
 * @author diana
 */
public class Statistica extends JFrame implements ActionListener{
      //static Gestiune g;
      JTextArea textArea, textArea2, textArea3;
    
    public Statistica(String text) {
        super(text);
      setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        textArea = new JTextArea(10, 20);
        textArea.setEditable(false);
        textArea.setFont(new Font("Serif", Font.ITALIC, 16));
        textArea2 = new JTextArea(10, 20);
        textArea2.setEditable(false);
        textArea2.setFont(new Font("Serif", Font.ITALIC, 16));
        textArea3 = new JTextArea(10, 20);
        textArea3.setEditable(false);
        textArea3.setFont(new Font("Serif", Font.ITALIC, 16));
        JButton button1 = new JButton("Magazin cu vanzari maxime");
        JButton button2 = new JButton("Magazin cu vanzari maxime");
        JButton button3 = new JButton("Magazin cu vanzari maxime");
//        textArea.setLineWrap(true);
//        textArea.setWrapStyleWord(true);
        JPanel panel1  = new JPanel(new FlowLayout());
        JPanel panel2 = new JPanel(new FlowLayout());

        panel1.setPreferredSize(new Dimension(300, 400));
        
        JScrollPane scrollPane = new JScrollPane(textArea);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        scrollPane.setPreferredSize(new Dimension(250,150));
        panel1.add(scrollPane);
        
        JScrollPane scrollPane2 = new JScrollPane(textArea2);
        scrollPane2.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        scrollPane2.setPreferredSize(new Dimension(250,150));
        panel1.add(scrollPane2);
        
        JScrollPane scrollPane3 = new JScrollPane(textArea3);
        scrollPane3.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        scrollPane3.setPreferredSize(new Dimension(250,150));
        panel1.add(scrollPane3);

        add(panel1, BorderLayout.WEST);
        panel2.add(button1);
        panel2.add(button2);
        panel2.add(button3);
        add(panel2);
        
        setSize(650,500);
        setLocationRelativeTo(null); 
        setVisible(true);
        setResizable(false);
    }
    
    /*public static void main(String args[]) {
        Menu b = new Menu("Menu");
    }*/

    @Override
    public void actionPerformed(ActionEvent e) {
        JButton button = (JButton) e.getSource();
        if (button.getText().equals("Magazin cu vanzari maxime")) {
            textArea.append("ss");
        }
        
    }
    
}