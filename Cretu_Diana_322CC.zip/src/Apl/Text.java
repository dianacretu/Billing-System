/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Apl;

/**
 *
 * @author diana
 */


import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Label;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class Text extends JFrame implements ActionListener{
   // private JButton button;
     String pr, tax, fac;
     static Gestiune g;
     GridBagConstraints gbc ;
     GridBagLayout gridBag ;
     TextField nume, categorie, tara, pret;
     
     void adauga ( Component comp ,int x, int y, int w, int h) {
		gbc . gridx = x;
		gbc . gridy = y;
		gbc . gridwidth = w;
		gbc . gridheight = h;
		gridBag . setConstraints (comp , gbc);
		add( comp );
	}
    
    public Text(String text) {
        super(text);
        gridBag = new GridBagLayout ();
        gbc = new GridBagConstraints ();
		gbc . weightx = 1.0;
		gbc . weighty = 1.0;
		gbc . insets = new Insets (5, 5, 5, 5);
                setLayout(gridBag);
    //    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      //  setMinimumSize(new Dimension(600,600));
        getContentPane().setBackground(Color.white);
      //  setLayout(new GridBagLayout());
        gbc = new GridBagConstraints();
        gbc.gridwidth = GridBagConstraints.REMAINDER;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc . fill = GridBagConstraints . NONE ;
        gbc . anchor = GridBagConstraints . EAST ;
        gbc.fill = GridBagConstraints . HORIZONTAL ;
        gbc.anchor = GridBagConstraints . CENTER ;
        JButton adaugare = new JButton("Adaugare");
        Label etNume = new Label (" Denumire :");
	adauga ( etNume , 0, 2, 1, 1);
	Label etCategorie = new Label (" Categorie :");
	adauga ( etCategorie , 0, 3, 1, 1);
        Label etTara = new Label (" Tara :");
	adauga ( etTara , 0, 4, 1, 1);
        Label etPret = new Label (" Pret :");
	adauga ( etPret , 0, 5, 1, 1);
	nume = new TextField ("", 30) ;
	adauga (nume , 1, 2, 2, 1);
	categorie = new TextField ("", 30) ;
        adauga ( categorie , 1, 3, 2, 1);
        tara = new TextField ("", 30) ;
        adauga ( tara , 1, 4, 2, 1);
        pret = new TextField ("", 30) ;
        adauga ( pret , 1, 5, 2, 1);
        adaugare.addActionListener(this);
        adaugare.setBackground(Color.pink);
        adauga ( adaugare , 3, 2, 1, 2);
        show();
        pack();  
    }
    
    /*public static void main(String args[]) {
        Menu b = new Menu("Menu");
    }*/

    @Override
    public void actionPerformed(ActionEvent e) {
        JButton button = (JButton) e.getSource();
        File produse, taxe, facturi;
        String numeP = "";
        String categorieP = "";
        String taraP = "";
        String pretP = "";
        
      
       // System.out.println(pr);
        //Gestiune g = Gestiune.getInstance();
        if (button.getText().equals("Adaugare")) {
            numeP = nume.getText();
            categorieP = categorie.getText();
            taraP = tara.getText();
            pretP = pret.getText();
            double pre = Double.parseDouble(pretP);
            Produs p = new Produs(numeP, categorieP, taraP, pre);
            System.out.println(p);
       //     System.out.println(Meniu.g.produse);
            if (numeP.equals("Da")) {
                System.out.println("yyyy");
            }
            int i = 0;
            for (i = 0; i < Meniu.g.produse.size(); i ++) {
                if (numeP.equals(Meniu.g.produse.get(i).getDenumire())) {
                    if (categorieP.equals(Meniu.g.produse.get(i).getCategorie())) {
                        if (taraP.equals(Meniu.g.produse.get(i).getTaraOrigine())) {
                            if (pre == Meniu.g.produse.get(i).getPret()) {
//                                JFrame f = new JFrame("!");
//                                f.setBackground(Color.red);
//                                Label a = new Label ("Produsul exista deja!");
//                                f.add(a);
//                                f.pack();
//                                f.show();
//                                break;
                                  JOptionPane.showMessageDialog(null, "Produsul exista!","Message", JOptionPane.ERROR_MESSAGE);
                            }
                        }
                    }
                }
            }
        
            if (i == Meniu.g.produse.size()) {
                FileWriter fw;
                try {
                    System.out.println("nu a mers");
                    Meniu.g.produse.add(p);
                    Vector<String> tariFisier = new Vector();
                    Scanner s = new Scanner(new File("produse.txt"));
                    String firstLine = s.nextLine();
                    Scanner sc = new Scanner(firstLine);
                    String tara = sc.next();
                    tara = sc.next();
                    System.out.println(tara);
                    while (sc.hasNext()) {
                        if (!sc.hasNext()) {
                            break;
                        }
                        tara = sc.next();
                        tariFisier.add(tara);
                    }   
                    Vector<String> liniiFisier = new Vector();
                    liniiFisier.add(firstLine);
                    System.out.println(tariFisier);
                    System.out.println(liniiFisier);
                    while (s.hasNext()) {
                        tara = s.nextLine();
                        liniiFisier.add(tara);
                    }   
                    File fisier = new File("ab.txt");
                    System.out.println(liniiFisier);
                    if (!fisier.exists()) {
                        try {
                            fisier.createNewFile();
                        } catch (IOException ex) {
                            Logger.getLogger(Text.class.getName()).log(Level.SEVERE, null, ex);
                        }
                    }   fw = new FileWriter(fisier);
                    BufferedWriter bw = new BufferedWriter(fw);
                    for (int indice = 0; indice < liniiFisier.size(); indice ++) {
                        bw.write(liniiFisier.get(indice));
                        bw.newLine();
                    }
                    bw.write(p.getDenumire());
                    bw.write(" ");
                    bw.write(p.getCategorie());
                    bw.write(" ");
                    int indice = 0;
                    for (indice = 0; indice < tariFisier.size(); indice ++) {
                        if (p.getTaraOrigine().equals(tariFisier.get(indice))) {
                            bw.write(pretP);
                            break;
                        }
                        else {
                            bw.write("0");
                            bw.write(" ");
                        }
                    }
                    while (indice == (tariFisier.size() - 1)) {
                        bw.write(" ");
                        bw.write("0");
                    }
                    bw.close();
                    fw.close();
                    
                } catch (IOException ex) {
                    Logger.getLogger(Text.class.getName()).log(Level.SEVERE, null, ex);
                } 
            }   
        }
    }
    
}
