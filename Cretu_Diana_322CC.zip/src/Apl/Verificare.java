/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Apl;

/**
 *
 * @author diana
 */

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collections;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author diana
 */
public class Verificare {
    
    public static void main(String args[]) throws FileNotFoundException, IOException {
        DecimalFormat format = new DecimalFormat("##.####");
        Gestiune g = Gestiune.getInstance();
        File f = new File("produse.txt");
        g.creazaProdus("produse.txt");
        g.creeazaFactura("facturi.txt", "taxe.txt");
        g.creeazaTaxe("taxe.txt");
        g.creeazaMagazin("facturi.txt", "taxe.txt");
    //    ScriereFisier sf = new ScriereFisier();
        File fisier = new File("src/out.txt");
        if (!fisier.exists()) {
            fisier.createNewFile();
        }
        FileWriter fw = new FileWriter(fisier);
        BufferedWriter bw = new BufferedWriter(fw);
        ArrayList<String> tipMagazin = new ArrayList();
        tipMagazin.add("MiniMarket");
        tipMagazin.add("MediumMarket");
        tipMagazin.add("HyperMarket");
        System.out.println(f.getAbsolutePath());
        int k = 0;
        for (k = 0; k < tipMagazin.size(); k ++) {
            bw.write(tipMagazin.get(k));
            ArrayList<Magazin> mag = new ArrayList();
            for(int i = 0; i <g.magazine.size(); i ++) {
                if (g.magazine.get(i).tip.equals(tipMagazin.get(k))) {
                    mag.add(g.magazine.get(i));
                }
            }
            Collections.sort(mag, new MagazinComparator());
            for (int i = 0; i < mag.size(); i ++) {
                bw.newLine();
                bw.write(mag.get(i).nume);
                bw.newLine();
                bw.newLine();
                bw.write("Total ");
                bw.write(format.format(mag.get(i).getTotalFaraTaxe()));
                bw.write(" ");
                bw.write(format.format(mag.get(i).getTotalCuTaxe()));
                bw.write(" ");
                bw.write(format.format(mag.get(i).getTotalCuTaxeScutite()));
                bw.newLine();
                bw.newLine();
                bw.write("Tara");
                bw.newLine();
                for (String tara : g.dictionar.keySet()) {
                    bw.write(tara);
                    bw.write(" ");
                    bw.write(format.format(mag.get(i).getTotalTaraFaraTaxe(tara)));
                    if (mag.get(i).getTotalTaraFaraTaxe(tara) != 0) {
                        bw.write(" ");
                        bw.write(format.format(mag.get(i).getTotalTaraCuTaxe(tara)));
                        bw.write(" ");
                        bw.write(format.format(mag.get(i).getTotalTaraCuTaxeScutite(tara)));
                    }
                    bw.newLine();
                }
                ArrayList<Factura> fac = new ArrayList();
                fac.addAll(mag.get(i).facturi);
                Collections.sort(fac, new FacturiComparator());
                System.out.println(fac);
                for(int j = 0; j < fac.size() ; j ++) {
                    bw.newLine();
                    bw.write(fac.get(j).denumire);
                    bw.newLine();
                    bw.newLine();
                    bw.write("Total ");
                    bw.write(format.format(fac.get(j).getTotalFaraTaxe()));
                    bw.write(" ");
                    bw.write(format.format(fac.get(j).getTotalCuTaxe()));
                    bw.newLine();
                    bw.newLine();
                    bw.write("Tara");
                    for (String tara : g.dictionar.keySet()) {
                        bw.newLine();
                        bw.write(tara);
                        bw.write(" ");
                        bw.write(format.format(fac.get(j).getTotalTaraFaraTaxe(tara)));
                        if (fac.get(j).getTotalTaraFaraTaxe(tara) != 0) {
                            bw.write(" ");
                            bw.write(format.format(fac.get(j).getTotalTaraCuTaxe(tara)));
                        }
                    }
                    bw.newLine();   
                }
            }
            if (k != (tipMagazin.size() - 1)) {
                bw.newLine();
            }
        }
        bw.close();
        fw.close();
    }
    
}

