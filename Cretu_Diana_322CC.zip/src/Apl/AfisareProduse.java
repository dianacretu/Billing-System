/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Apl;

import java.awt.*;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Vector;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;

/**
 *
 * @author diana
 */
public class AfisareProduse extends JFrame implements ActionListener{
   // private JButton button;
     String pr, tax, fac;
     Label statusLabel;
     Choice showChoice;
     
    
    public AfisareProduse(String text) {
        super(text);
    //    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setMinimumSize(new Dimension(600,600));
        getContentPane().setBackground(Color.white);
        setLayout(new FlowLayout());
        GridBagConstraints gbc = new GridBagConstraints();
    //    JFrame.setDefaultLookAndFeelDecorated(true);

        gbc.gridwidth = GridBagConstraints.REMAINDER;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        showChoice = new Choice();
        showChoice.add("Denumire");
        showChoice.add("Tara");
        showChoice.setBackground(Color.white);
        JButton button = new JButton("Show");
        JButton adaugare = new JButton("Adauga produs");
        JButton stergere = new JButton("Sterge produs");
        button.addActionListener(this);
        adaugare.addActionListener(this);
        stergere.addActionListener(this);
        button.setBackground(Color.pink);
        statusLabel = new Label();
        add(showChoice, gbc);
        add(button, gbc);
        add(statusLabel);
        add(adaugare, gbc);
        add(stergere, gbc);
        pack();  
        show();
    }
    
    /*public static void main(String args[]) {
        Menu b = new Menu("Menu");
    }*/

    @Override
    public void actionPerformed(ActionEvent e) {
        String pls = (String) showChoice.getItem(showChoice.getSelectedIndex());
        JButton button = (JButton) e.getSource();
        if (button.getText().equals("Adauga produs")) {
            Text ad = new Text("Adaugare");
        }
        if (pls.equals("Tara") && button.getText().equals("Show")) {
          // Tabel t = new Tabel("Tabel denumire", new TaraComparator());
          new JTableRowScrollingExample().setVisible(true);
        }
        
        if (pls.equals("Denumire") && button.getText().equals("Show")) {
       
            Tabel t = new Tabel("Tabel denumire", new NumeComparator());
          
        }
        if (button.getText().equals("Sterge produs")) {
            Sterge s = new Sterge("Sterge produs");
        }
    }
}

