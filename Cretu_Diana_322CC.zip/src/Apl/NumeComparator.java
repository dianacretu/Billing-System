/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Apl;

import java.util.Comparator;

/**
 *
 * @author diana
 */
public class NumeComparator implements Comparator{

    @Override
    public int compare(Object o1, Object o2) {
        Produs p1 = (Produs) o1;
        Produs p2 = (Produs) o2;
        return p1.getDenumire().compareTo(p2.getDenumire());
    }
    
}
