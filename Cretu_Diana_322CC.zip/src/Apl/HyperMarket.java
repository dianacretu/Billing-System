/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Apl;

/**
 *
 * @author diana
 */
import java.util.Vector;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author diana
 */
public class HyperMarket extends Magazin{
 //   String tip;
    
    HyperMarket(String nume, String tip, Vector facturi) {
        super(nume, tip, facturi);
        this.tip = tip;
    }

    @Override
    public double calculScutiriTaxe() {
        for (int i = 0; i < facturi.size(); i ++) {
            if (facturi.get(i).getTotalCuTaxe() > getTotalCuTaxe()*0.1) {
                return 0.01;
            }
        }
        return 0;
    }
    
    
}
