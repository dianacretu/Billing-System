/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Apl;

/**
 *
 * @author diana
 */
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Label;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;

public class Editare extends JFrame implements ActionListener{
     Produs p;
     static Gestiune g;
     GridBagConstraints gbc ;
     GridBagLayout gridBag ;
     TextField nume, categorie, tara, pret;
     
     void adauga ( Component comp ,int x, int y, int w, int h) {
		gbc . gridx = x;
		gbc . gridy = y;
		gbc . gridwidth = w;
		gbc . gridheight = h;
		gridBag . setConstraints (comp , gbc);
		add( comp );
	}
    
    public Editare(String text, Produs p) {
        super(text);
        this.p = p;
        gridBag = new GridBagLayout ();
        gbc = new GridBagConstraints ();
		gbc . weightx = 1.0;
		gbc . weighty = 1.0;
		gbc . insets = new Insets (5, 5, 5, 5);
                setLayout(gridBag);
    //    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      //  setMinimumSize(new Dimension(600,600));
        getContentPane().setBackground(Color.white);
      //  setLayout(new GridBagLayout());
        gbc = new GridBagConstraints();
        gbc.gridwidth = GridBagConstraints.REMAINDER;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc . fill = GridBagConstraints . NONE ;
        gbc . anchor = GridBagConstraints . EAST ;
        gbc.fill = GridBagConstraints . HORIZONTAL ;
        gbc.anchor = GridBagConstraints . CENTER ;
        JButton adaugare = new JButton("Editare");
        Label etNume = new Label (" Denumire :");
	adauga ( etNume , 0, 2, 1, 1);
	Label etCategorie = new Label (" Categorie :");
	adauga ( etCategorie , 0, 3, 1, 1);
        Label etTara = new Label (" Tara :");
	adauga ( etTara , 0, 4, 1, 1);
        Label etPret = new Label (" Pret :");
	adauga ( etPret , 0, 5, 1, 1);
	nume = new TextField ("", 30) ;
	adauga (nume , 1, 2, 2, 1);
	categorie = new TextField ("", 30) ;
        adauga ( categorie , 1, 3, 2, 1);
        tara = new TextField ("", 30) ;
        adauga ( tara , 1, 4, 2, 1);
        pret = new TextField ("", 30) ;
        adauga ( pret , 1, 5, 2, 1);
        adaugare.addActionListener(this);
        adaugare.setBackground(Color.pink);
        adauga ( adaugare , 3, 2, 1, 2);
        show();
        pack();  
    }
    
    /*public static void main(String args[]) {
        Menu b = new Menu("Menu");
    }*/

    @Override
    public void actionPerformed(ActionEvent e) {
        JButton button = (JButton) e.getSource();
        File produse, taxe, facturi;
        String numeP = "";
        String categorieP = "";
        String taraP = "";
        String pretP = "";
        
      
       // System.out.println(pr);
        //Gestiune g = Gestiune.getInstance();
        if (button.getText().equals("Editare")) {
            System.out.println("works");
            numeP = nume.getText();
            System.out.println(numeP);
            categorieP = categorie.getText();
            taraP = tara.getText();
            pretP = pret.getText();
            double pre = Double.parseDouble(pretP);
           // Produs p = new Produs(numeP, categorieP, taraP, pre);
            System.out.println(p);
            int i = 0;
            for (i = 0; i < Meniu.g.produse.size(); i ++) {
                if (p.getDenumire().equals(Meniu.g.produse.get(i).getDenumire())) {
                    if (p.getCategorie().equals(Meniu.g.produse.get(i).getCategorie())) {
                        if (p.getTaraOrigine().equals(Meniu.g.produse.get(i).getTaraOrigine())) {
                            if (p.getPret() == Meniu.g.produse.get(i).getPret()) {
                                Meniu.g.produse.get(i).setDenumire(numeP);
                                Meniu.g.produse.get(i).setCategorie(categorieP);
                                Meniu.g.produse.get(i).setTaraOrigine(taraP);
                                Meniu.g.produse.get(i).setPret(pre);
                                System.out.println(Double.toString(Meniu.g.produse.get(i).getPret()));
                                break;
                            }
                        }
                    }
                }
            }
            FileWriter fw;
            try {
                Vector<String> tariFisier = new Vector();
                Scanner s = new Scanner(new File("produse.txt"));
                String firstLine = s.nextLine();
                File fisier = new File("ab.txt");
                fw = new FileWriter(fisier);
                BufferedWriter bw = new BufferedWriter(fw);
                bw.write(firstLine);
                bw.newLine();
                for (i = 0; i < Meniu.g.produse.size(); i ++) {
                    if (i > 0) {
                            if (!Meniu.g.produse.get(i).getDenumire()
                                .equals(Meniu.g.produse.get(i - 1).getDenumire())) {
                                bw.newLine();
                                bw.write(Meniu.g.produse.get(i).getDenumire());
                                bw.write(Meniu.g.produse.get(i).getTaraOrigine());
                                bw.write(" ");
                            }
                      //  }
                        bw.write(" ");
                        bw.write(Double.toString(Meniu.g.produse.get(i).getPret()));
                    }
                    else {
                        bw.write(Meniu.g.produse.get(i).getDenumire());
                        bw.write(" ");
                        bw.write(Meniu.g.produse.get(i).getCategorie());
                        bw.write(" ");
                        bw.write(Double.toString(Meniu.g.produse.get(i).getPret()));
                    }
                }
                bw.close();
                fw.close();
                    
                } catch (IOException ex) {
                    Logger.getLogger(Text.class.getName()).log(Level.SEVERE, null, ex);
                } 
              
        }
    }
    
}
