/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Apl;

/**
 *
 * @author diana
 */

import java.util.Vector;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author diana
 */

import java.util.Vector;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author diana
 */
public class MediumMarket extends Magazin{
  //  String tip;
    
    MediumMarket(String nume, String tip, Vector facturi) {
        super(nume, tip, facturi);
       // this.tip = tip;
    }
    
    @Override
    public double calculScutiriTaxe() {
        Vector<String> categorie = new Vector();
        String catProdus = " ";
        for (int i = 0; i < facturi.size(); i ++) {
            for (int j = 0; j < facturi.get(i).produseCom.size(); j ++) {
                if (!categorie.contains(facturi.get(i).produseCom.get(j).getProdus().getCategorie())) {
                    catProdus = facturi.get(i).produseCom.get(j).getProdus().getCategorie();
                    categorie.add(catProdus);
                }
            }
        }
        double suma = 0;
        for (int i = 0; i < categorie.size(); i ++) {
            for (int j = 0; j < facturi.size(); j ++) {
                for (int k = 0; k < facturi.get(j).produseCom.size(); k ++) {
                    if (categorie.get(i).equals(facturi.get(j).produseCom.get(k).getProdus().getCategorie())) {
                        suma = suma + facturi.get(j).produseCom.get(k).getCantitate() * facturi.get(j).produseCom.get(k).getProdus().getPret()
                       // suma = suma + facturi.get(j).produseCom.get(k).getCantitate() * facturi.get(j).produseCom.get(k).getTaxe();
                                                                  * (facturi.get(j).produseCom.get(k).getTaxe() + 100)/100;                     
                    }
                }
            }
            if (suma > (getTotalCuTaxe())/2) {
                return 0.05;
            }
            suma = 0;
        }
        return 0;
    }
    
}

