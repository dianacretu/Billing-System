/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Apl;

/**
 *
 * @author diana
 */
import java.awt.Choice;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;

/**
 *
 * @author diana
 */public class Sterge extends JFrame implements ActionListener{
   // private JButton button;
     String pr, tax, fac;
     static Gestiune g;
     Choice showChoice;
    
    public Sterge(String text) {
        super(text);
    //    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setMinimumSize(new Dimension(600,600));
        getContentPane().setBackground(Color.black);
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridwidth = GridBagConstraints.REMAINDER;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        showChoice = new Choice();
        for (int i = 0; i < Meniu.g.produse.size(); i ++) {
            showChoice.add(Meniu.g.produse.get(i).toString());
        }
        showChoice.setBackground(Color.white);
        JButton stergere = new JButton("Sterge");
        JButton editare = new JButton("Editeaza");
        stergere.addActionListener(this);
        editare.addActionListener(this);
        stergere.setBackground(Color.pink);
        editare.setBackground(Color.pink);
     //   button.setSize(2,1);
        add(showChoice, gbc);
        stergere.addActionListener(this);
    //    button2.setSize(1,1);
        add(stergere, gbc);
        add(editare, gbc);
        show();
        pack();  
    }
    
    /*public static void main(String args[]) {
        Menu b = new Menu("Menu");
    }*/

    @Override
    public void actionPerformed(ActionEvent e) {
        JButton button = (JButton) e.getSource();
        String pls = (String) showChoice.getItem(showChoice.getSelectedIndex());
        String path = "";
        Scanner s = new Scanner(pls);
        String denumire = s.next();
        String categorie = s.next();
        String tara = s.next();
        double pret = Double.parseDouble(s.next());
        if (button.getText().equals("Sterge")) {
           for (int i = 0; i < Meniu.g.produse.size(); i ++) {
               if (Meniu.g.produse.get(i).getDenumire().equals(denumire)) {
                  if (Meniu.g.produse.get(i).getCategorie().equals(categorie)) {
                      if (Meniu.g.produse.get(i).getTaraOrigine().equals(tara)) {
                          if (Meniu.g.produse.get(i).getPret() == pret) {
                              Meniu.g.produse.remove(Meniu.g.produse.get(i));
                              break;
                          }
                      }
                  } 
               }
           }
        }
        if (button.getText().equals("Editeaza")) {
            Produs p = new Produs(denumire, categorie, tara, pret);
            Editare edit = new Editare("Editare", p);
        }
    }
    
}

