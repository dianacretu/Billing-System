/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Apl;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;

/**
 *
 * @author diana
 */public class Meniu extends JFrame implements ActionListener{
   // private JButton button;
     String pr, tax, fac;
     static Gestiune g;
    
    public Meniu(String text) {
        super(text);
    //    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setMinimumSize(new Dimension(600,600));
        getContentPane().setBackground(Color.black);
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        JFrame.setDefaultLookAndFeelDecorated(true);
        gbc.gridwidth = GridBagConstraints.REMAINDER;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        JButton button = new JButton("Incarcare produse.txt");
        JButton button2 = new JButton("Incarcare taxe.txt");
        JButton button3 = new JButton("Incarcare facturi.txt");
        JButton button4 = new JButton("Gestiune");
        button.addActionListener(this);
        button.setBackground(Color.pink);
     //   button.setSize(2,1);
        button2.addActionListener(this);
        button2.setBackground(Color.pink);
        button3.addActionListener(this);
        button3.setBackground(Color.pink);
        button4.addActionListener(this);
        button4.setBackground(Color.pink);
    //    button2.setSize(1,1);
        add(button, gbc);
        add(button2, gbc);
        add(button3, gbc);
        add(button4, gbc);
        show();
        pack();  
    }
    
    /*public static void main(String args[]) {
        Menu b = new Menu("Menu");
    }*/

    @Override
    public void actionPerformed(ActionEvent e) {
        JButton button = (JButton) e.getSource();
        File produse, taxe, facturi;
        String path = "";
        
      
       // System.out.println(pr);
        //Gestiune g = Gestiune.getInstance();
        if (button.getText().equals("Incarcare produse.txt")) {
           JFileChooser fc = new JFileChooser();
           int option = fc.showOpenDialog(null);
           if(option == JFileChooser.APPROVE_OPTION) {
                produse = fc.getSelectedFile();
                pr = produse.toString();
            
        }
           
           else if (option == JFileChooser.CANCEL_OPTION){
                System.out.println(" User cancelled operation. No file was chosen.");  
           }
           button.setBackground(Color.blue);
        } 
       /* else {
            pr = "ab.txt";
        }*/
   //    System.out.println(pr);
     
        if (button.getText().equals("Incarcare taxe.txt")) {
           JFileChooser fc = new JFileChooser();
           int option = fc.showOpenDialog(null);
         /*  fc = new JFileChooser();
            option = fc.showOpenDialog(null);*/
           if(option == JFileChooser.APPROVE_OPTION) {
                taxe = fc.getSelectedFile();
                tax = taxe.toString();
              /* try {
                   g.creeazaTaxe(tax);
               } catch (FileNotFoundException ex) {
                   System.out.println("nuTaxe");
               }*/
           }
           else if (option == JFileChooser.CANCEL_OPTION){
                System.out.println(" User cancelled operation. No file was chosen.");  
           }
           button.setBackground(Color.blue);
        }
     //   System.out.println(tax);
        
            if (button.getText().equals("Incarcare facturi.txt")) {
               JFileChooser fc = new JFileChooser();
               int option = fc.showOpenDialog(null);
           /* fc = new JFileChooser();
            option = fc.showOpenDialog(null);*/
               if(option == JFileChooser.APPROVE_OPTION) {
                    facturi = fc.getSelectedFile();
                    fac = facturi.toString();
                /*   try {
                       g.creeazaFactura(fac, tax);
                   } catch (FileNotFoundException ex) {
                       System.out.println("nuFac");
                   }*/
               }
               else if (option == JFileChooser.CANCEL_OPTION){
                    System.out.println(" User cancelled operation. No file was chosen.");  
               }
               button.setBackground(Color.blue);
            }
          //  System.out.println(fac);
        
        if (button.getText().equals("Gestiune")) {
            g = Gestiune.getInstance();
            try {
                g.creazaProdus(pr);
                /* try {
                g.creazaProdus(path);
                } catch (FileNotFoundException ex) {
                System.out.println("nu");
                }*/
                //   g.creeazaFactura(fac, tax);
                //  g.creeazaTaxe("taxe.txt");
                //g.creeazaMagazin("facturi.txt", "taxe.txt");
            } catch (FileNotFoundException ex) {
                System.out.println("nu");
            }
            try {
                g.creeazaFactura(fac, tax);
            } catch (FileNotFoundException ex) {
                System.out.println("nu2");
            }
            try {
                g.creeazaTaxe(tax);
            } catch (FileNotFoundException ex) {
                System.out.println("nu3");
            }
            try {
                g.creeazaMagazin("facturi.txt", "taxe.txt");
            } catch (FileNotFoundException ex) {
                System.out.println("nu4");
            }
           button.setBackground(Color.blue);
        }
    }
    
}
