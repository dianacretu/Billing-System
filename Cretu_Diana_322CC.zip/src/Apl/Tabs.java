/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Apl;

import com.sun.glass.events.KeyEvent;
import javax.swing.*;

/**
 *
 * @author diana
 */
public class Tabs extends JTabbedPane{
    void creare(){
        JTabbedPane tabb = new JTabbedPane();
        JComponent panel1 = new JPanel();
        panel1.setOpaque(true);
        ImageIcon icon = new ImageIcon("smiley.gif");
        panel1.add(new JLabel("Home"));
        tabb.addTab("Home", icon, panel1, "");
        tabb.setMnemonicAt(0, KeyEvent.VK_1);
        JComponent panel2 = new JPanel();
        panel2.setOpaque(true);
        panel2.add(new JButton("ok"));
        tabb.addTab("Tab 2", panel2);
        tabb.setMnemonicAt(1, KeyEvent.VK_2);
        tabb.show();
    }
    
    public static void main(String args[]) {
        Tabs t = new Tabs();
    }
}
