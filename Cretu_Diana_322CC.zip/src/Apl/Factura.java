/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Apl;

/**
 *
 * @author diana
 */

import java.util.Vector;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author diana
 */
public class Factura {
    String denumire;
    Vector<ProdusComandat> produseCom;
    
    Factura(String denumire, Vector<ProdusComandat> produseCom) {
        this.denumire = denumire;
        this.produseCom = produseCom;
    }
    
    double getTotalFaraTaxe() {
        double suma = 0;
        for (int i = 0; i < produseCom.size(); i ++) {
            suma = suma + produseCom.get(i).getCantitate() * produseCom.get(i).getProdus().getPret();
        }
        return suma;
    }
    
    double getTotalCuTaxe() {
        double suma = 0;
        for (int i = 0; i < produseCom.size(); i ++) {
            suma = suma + produseCom.get(i).getCantitate() 
                        * produseCom.get(i).getProdus().getPret()
                            *(produseCom.get(i).getTaxe() + 100)/100;
        }
        return suma;
    }
    
    double getTaxe() {
        double suma = 0;
        for (int i = 0; i < produseCom.size(); i ++) {
            suma = suma + produseCom.get(i).getCantitate() * produseCom.get(i).getTaxe();
        }
        return suma;
    }
    
    double getTotalTaraFaraTaxe(String tara) {
        double suma = 0;
        for (int i = 0; i < produseCom.size(); i ++) {
            if (produseCom.get(i).getProdus().getTaraOrigine().equals(tara)) {
                suma = suma + produseCom.get(i).getCantitate() * produseCom.get(i).getProdus().getPret();
            }
        }
        return suma;
    }
    
    double getTotalTaraCuTaxe(String tara) {
        double suma = 0;
        for (int i = 0; i < produseCom.size(); i ++) {
            if (produseCom.get(i).getProdus().getTaraOrigine().equals(tara)) {
                suma = suma + produseCom.get(i).getCantitate() 
                        * produseCom.get(i).getProdus().getPret()*( produseCom.get(i).getTaxe()+100)/100;
               // suma = suma + produseCom.get(i).getCantitate() * produseCom.get(i).getTaxe();
            }
        }
        return suma;
    }
    
    double getTaxeTara(String tara) {
       double suma = 0;
        for (int i = 0; i < produseCom.size(); i ++) {
            if (produseCom.get(i).getProdus().getTaraOrigine().equals(tara)) {
                suma = suma + produseCom.get(i).getCantitate() * produseCom.get(i).getTaxe();
            }
        }
        return suma;
    }
    
    public String toString() {
        return denumire + " " + produseCom;
    }
}

