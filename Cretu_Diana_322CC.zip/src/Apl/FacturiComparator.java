/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Apl;

/**
 *
 * @author diana
 */
import java.util.Comparator;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author diana
 */
public class FacturiComparator implements Comparator{

    @Override
    public int compare(Object o1, Object o2) {
        Factura m1 = (Factura) o1;
        Factura m2 = (Factura) o2;
        return (int) (m1.getTotalCuTaxe() - m2.getTotalCuTaxe());
    }
    
}
