/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Apl;

import static com.sun.xml.internal.fastinfoset.alphabet.BuiltInRestrictedAlphabets.table;
import static java.awt.AWTEventMulticaster.add;
import static java.awt.AWTEventMulticaster.add;
import static java.awt.AWTEventMulticaster.add;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Vector;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ScrollPaneConstants;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author diana
 */
public class Tabel extends JFrame implements ActionListener {
   // private JButton button;
    JTable table = new JTable();
    JTextField fieldRowNumber = new JTextField(5);
    JButton buttonScroll = new JButton("Scroll to");
     String pr, tax, fac;
     static Gestiune g;
    
    public Tabel(String text, Comparator c) {
        super(text);
    //    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setMinimumSize(new Dimension(600,600));
        getContentPane().setBackground(Color.black);
       // setLayout(new GridBagLayout());
       setLayout(new BorderLayout());
        ArrayList<Produs> prod = new ArrayList();
        prod.addAll(Meniu.g.produse);
        Collections.sort(prod, c);
        Vector<String> nr = new Vector();
        Vector<Vector<String>> produse = new Vector();
        Vector<String> adds; 
        nr.add("Cols");
        for (int i = 0; i < prod.size(); i ++) {
            adds = new Vector();
             adds.add(prod.get(i).toString());
                produse.add(adds);
            }
      //  JTable tabel = new JTable(produse, nr);
      DefaultTableModel model = new DefaultTableModel(produse, nr);
      table.setModel(model);
        JScrollPane tableScrollPane = new JScrollPane(table);
        //setAutoResizeMode(tabel.AUTO_RESIZE_OFF); 
        tableScrollPane.setPreferredSize(new Dimension(300, 150));
    //    tabel.setAutoscrolls(rootPaneCheckingEnabled);
     //   tabel.setSize(600, 600);
       // tabel.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);

     //   tableScrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
    //    tableScrollPane.setViewportView(tabel);
//    JPanel panel = new JPanel();
//		panel.setLayout(new FlowLayout());
//		panel.add(label);
//		panel.add(fieldRowNumber);
//		panel.add(buttonScroll);
//		
//		add(panel, BorderLayout.NORTH);
		
	//	buttonScroll.addActionListener(this);
        add(tableScrollPane, BorderLayout.CENTER);
       // show();
        pack();
        show();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        int rowNumber = Integer.parseInt(fieldRowNumber.getText());
		Rectangle cellRect = table.getCellRect(rowNumber, 0, false);
		System.out.println(cellRect);
		table.scrollRectToVisible(cellRect);
    }
    
}