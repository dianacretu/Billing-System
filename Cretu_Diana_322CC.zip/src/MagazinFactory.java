
import java.util.Vector;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author diana
 */
public class MagazinFactory {
    public static Magazin getMagazin(String nume, String tip, Vector facturi) {
        Magazin m = null;
        switch(tip){
            case "MiniMarket":
                m = new MiniMarket(nume, tip, facturi);
                break;
                
            case "MediumMarket":
                m = new MediumMarket(nume, tip, facturi);
                break;
                
            case "HyperMarket":
                m = new HyperMarket(nume, tip, facturi);
                break;
                
            default:
                break;
        }
        return m;        
    }
}
